#!/bin/bash

set -uo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export PROJECT_ROOT

CONFIG_DIR="${PROJECT_ROOT}/config"
LIB_DIR="${PROJECT_ROOT}/lib"
COLLECTOR_DIR="${PROJECT_ROOT}/collectors"
OUTPUT_DIR="${PROJECT_ROOT}/output"
LOG_DIR="${PROJECT_ROOT}/logs"

mkdir -p "$OUTPUT_DIR"
mkdir -p "$LOG_DIR"

for LIB in "$LIB_DIR"/*.sh
do
    [ -f "$LIB" ] && source "$LIB"
done

for CFG in "$CONFIG_DIR"/*.conf
do
    [ -f "$CFG" ] && source "$CFG"
done

MODE="${1:-run}"

case "$MODE" in

    --list)

        list_collectors
        exit 0
        ;;

esac

acquire_lock
trap release_lock EXIT

agent_init

while IFS= read -r COLLECTOR
do

    echo "[RUN ] ${COLLECTOR#$PROJECT_ROOT/}"
    run_collector "$COLLECTOR"

done < <(find "$COLLECTOR_DIR" -type f -name "*.sh" | sort)

evaluate_health
build_json

if [ "${BUILD_PDF:-1}" = "1" ]; then
    build_pdf
fi

if [ "${BUILD_MANAGEMENT_PDF:-1}" = "1" ]; then
    build_management_pdf
fi

if [ "$MODE" = "--report" ]
then
    print_report
    exit 0
fi

send_json

echo
echo "========================================"
echo "Agent Finished"
echo "Output : ${OUTPUT_JSON}"
echo "Keys   : ${#DATA[@]}"
echo "========================================"
echo
